gunakan website conversi mp3 to opus atau m4a to opus

https://convertio.co/mp3-opus/
https://convertio.co/m4a-opus/
